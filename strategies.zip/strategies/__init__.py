import app.Config as Config
from app.adaptation.strategies.AvoidOverloadedStreets import AvoidOverLoadedStreets
from app.adaptation.strategies.LoadBalancing import LoadBalancing
from app.adaptation.strategies.TunePlanningResolution import TunePlanningResolution
from app.adaptation.strategies.AOS_LB import AOS_LB
from app.adaptation.strategies.TPR_AOS import TPR_AOS
from app.adaptation.strategies.TPR_LB import TPR_LB
def get_adaptation_stategy(tick):

    if Config.adaptation_strategy == "load_balancing":
        return LoadBalancing(tick)
    elif Config.adaptation_strategy == "avoid_overloaded_streets":
        return AvoidOverLoadedStreets(tick)
    elif Config.adaptation_strategy == "tune_planning_resolution":
        return TunePlanningResolution(tick)
    elif Config.adaptation_strategy == "aos_lb":
        return AOS_LB(tick)
    elif Config.adaptation_strategy == "tpr_aos":
        return TPR_AOS(tick)
    elif Config.adaptation_strategy == "tpr_lb":
        return TPR_LB(tick)
