from app.adaptation.Strategy import Strategy
from app.adaptation.Util import *
from app.adaptation import Knowledge
from app.network.Network import Network
from app.Config import adaptation_period
import csv
from numpy import mean


class AOS_LB(Strategy):

    def monitor(self):
        return Util.get_street_utilizations(Knowledge.time_of_last_adaptation, adaptation_period)[0], Util.get_trip_overheads(Knowledge.time_of_last_adaptation, adaptation_period)

    def analyze(self, monitor_data):
        utilizations=monitor_data[0]
        trip_overheads=monitor_data[1]
        mean_overhead = mean(trip_overheads)
        print "Mean overhead is: " +  str(mean_overhead)        
        overloaded_streets = []
        for street, utilizations in utilizations.iteritems():
            mean_utilization = mean(utilizations)
            if mean_utilization > 0.4:
                print "overloaded street: " + str(street)
                overloaded_streets.append(street)
        return overloaded_streets, mean_overhead

    def plan(self, monitor_data):
        overloaded_streets=monitor_data[0]
        mean_overhead=monitor_data[1]

        avoid_streets_signal = []
        for i in range(Knowledge.planning_steps):
            avoid_streets_signal += [0 if edge.id in overloaded_streets else 1 for edge in Network.routingEdges]
        if mean_overhead > 3.5:
            print "Mean overhead threshold reached!"
            return avoid_streets_signal,0.9
        return avoid_streets_signal,1



    def execute(self, monitor_data):
        avoid_streets_signal=monitor_data[0]
        beta_value=monitor_data[1]
        Knowledge.beta = beta_value
        if len(avoid_streets_signal) > 0:
            print "Sending signal to avoid overloaded streets!"
        with open('datasets/plans/signal.target', 'w') as signal_fil:
            signal_writer = csv.writer(signal_fil, dialect='excel')
            signal_writer.writerow(avoid_streets_signal)
        print "Setting beta to " + str(beta_value)

        Knowledge.globalCostFunction = "XCORR"
